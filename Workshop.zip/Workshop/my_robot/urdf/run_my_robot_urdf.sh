roslaunch urdf_tutorial display.launch model:=/home/user/catkin_ws/src/Robotics_Workshop/my_robot/urdf/run_my_robot_urdf.sh
