roslaunch urdf_tutorial display.launch model:=My_Robot.urdf
