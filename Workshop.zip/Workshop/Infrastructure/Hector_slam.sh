cd ~/catkin/src
git clone https://github.com/DaikiMaekawa/hector_slam_example.git
apt-get install ros-kinetic-hector-slam

