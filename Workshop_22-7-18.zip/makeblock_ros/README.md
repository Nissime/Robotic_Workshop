# makeblock-ros
Makeblock Orion ros bridge.

Features:
--
- Get ultrasonic sensor data - Topic 
- Move robot - Service (rosservice call /makeblock_ros_move_motors -- 0 0)

Required:
--
- pip install megapi
- pip install pySerial

Installation:
--
cd ~/catkin_ws/src

git clone ..
