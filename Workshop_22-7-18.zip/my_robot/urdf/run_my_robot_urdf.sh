roslaunch urdf_tutorial display.launch model:=/home/rosbot1/catkin_ws/src/Workshop/my_robot/urdf/My_Robot1.urdf

