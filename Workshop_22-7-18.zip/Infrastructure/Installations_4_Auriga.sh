sudo pip install megapi
