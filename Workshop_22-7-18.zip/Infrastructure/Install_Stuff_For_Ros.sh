
sudo apt-get install ros-kinetic-teleop-twist-keyboard 

